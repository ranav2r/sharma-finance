Sharma Finance Group V106
Updated page colors for stronger text contrast: light page backgrounds, dark readable text, white form surfaces, clearer table rows and visible input text. Colorful summary cards are retained.
Open index.html in a browser. Existing Supabase configuration remains in the HTML file.
